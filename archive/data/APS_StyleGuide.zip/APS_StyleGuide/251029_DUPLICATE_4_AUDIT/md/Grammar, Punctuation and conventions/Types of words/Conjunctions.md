# Conjunctions

Conjunctions join whole sentences or parts of a sentence together. They can show people how ideas are linked, or how ideas contrast.

---

## Guidance

- Conjunctions join words, phrases and clauses  
- Some conjunctions are paired  
- Coordinating conjunctions join things of equal importance  
- Subordinating conjunctions join clauses and phrases to a main clause  
- Some adverbs work as conjunctions  
- ‘With’ is not a conjunction  

---

## Conjunctions join words, phrases and clauses

Use conjunctions to connect words, phrases and clauses.

Examples of conjunctions are:

- and  
- but  
- or  
- because  
- when.  

**Example**  
> The team met early because the manager requested it.  
> Print the page in black and white, please.  
> Lee wanted casual or part-time work.  
> Give me a call when you have finished the report.

---

## Some conjunctions are paired

Some conjunctions come in pairs, such as *whether/or*, *either/or* and *neither/nor*. Each conjunction in the pair should appear before the same type of word, phrase or clause.

**Example**  
> Whether rain or shine, we’re going ahead with the team-building exercise. [Both conjunctions pair with a noun.]  
> My manager and I discussed both my performance review and my career prospects. [Both conjunctions pair with a noun phrase.]  
> Either we complete the report today, or we work on it tomorrow. [Both conjunctions pair with clauses.]

---

## Coordinating conjunctions join things of equal importance

Coordinating conjunctions include *and*, *but* and *or*. They link words, phrases and clauses that are of the same importance.

**Example**  
> The Australian Defence Force will build new patrol boats and submarines. [Joining nouns]  
> Work quickly but carefully. [Joining adverbs]  
> The answer is true or false. [Joining adjectives]  
> The content designers had Post-its on the wall and on the floor. [Joining phrases]  
> Schools reopened so students returned. [Joining clauses]

Coordinating conjunctions can also join clauses that could stand alone as sentences.

**Example**  
> Keep the sentence simple otherwise the message will get lost.

---

## Subordinating conjunctions join clauses and phrases to a main clause

Subordinating conjunctions join the main clause to a subordinate (or ‘dependent’) clause or phrase.

The main clause can stand alone as a sentence. Dependent clauses add to the main clause: they depend on it to form a complete sentence.

Examples of subordinating conjunctions are:

- when  
- if  
- unless  
- until  
- because  
- since.  

**Example**  
> When you get to work, please phone your new client. [‘Please phone your new client’ is the main clause; ‘when you get to work’ is the dependent clause.]  
> Take care of your health as though your life depends on it. [‘Take care of your health’ is the main clause; ‘your life depends on it’ is the dependent clause.]

---

## Some adverbs work as conjunctions

A conjunctive adverb is a word that does 2 things at the same time:

1. It joins 2 main clauses.  
2. It modifies a verb, an adjective, another adverb or a whole clause.  

They are weaker connections than coordinating or subordinating conjunctions.

**Example**  
> A quick guide outlines the issue, besides detailing other sources on the topic.

Conjunctive adverbs are often not needed. They add nuance to writing, but use them sparingly. You can usually delete them and keep meaning clear.

**Example**  
> The deadline was still weeks away; however, it was going to be tough to meet. [The adverb ‘however’ links 2 main clauses.]  
> The deadline was still weeks away. It was going to be tough to meet. [No adverb links the 2 main clauses.]

---

## ‘With’ is not a conjunction

Don’t use *with* to add a clause at the beginning or end of a sentence. Reword or split the sentence to prevent this misuse. This helps create shorter, simpler sentences that are easier to read.

**Correct**  
> The lake has had several blue-green algae outbreaks this year. It has been closed to swimming at least once a year since 2002.

**Incorrect**  
> The lake has had several blue-green algae outbreaks this year, with the lake closed to swimming at least once a year since 2002.

---

## Release notes

The digital edition expands what was in the sixth edition by providing context and more examples. The information is consolidated in one page to help the user.

The sixth edition had information about conjunctions in many sections of the manual.

The *Content Guide* did not have any information about conjunctions.
