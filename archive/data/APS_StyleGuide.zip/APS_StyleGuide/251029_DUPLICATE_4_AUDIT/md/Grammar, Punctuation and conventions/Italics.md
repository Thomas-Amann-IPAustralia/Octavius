# Italics

Italic type contrasts with roman type. It draws people’s attention to convey meaning. Use italic type sparingly as it can affect readability.

---

## Guidance

- Limit use of italics  
- Italicise titles of stand-alone works, legal cases and Acts  
- Set off most foreign words and phrases  
- Don’t use italics for Latin shortened forms  
- Show that formulas and some text have special meaning  
- Stress words with special emphasis, but rarely  

---

## Limit use of italics

Italics are sloping letters. Roman type is upright and the default font type.

Italic type makes text stand out from surrounding roman type. The contrast can help readers notice important words, identify differences and find those words again.

**Example**  
> The Australian of the Year honour is a government award. It is different from *The Australian*’s annual award of the same name.  
> [Publication titles use italics, but not awards.]

Italics lose their effectiveness when many italicised words appear on a page.

Limit italics to the uses described on this page, which link to detailed guidance.

**Don’t use italics for:**

- large blocks of text  
- material that would normally be in italics but is set apart (such as a list of titles under a heading)  
- aggregation pages (such as a page listing legislation).  

Overuse affects the content’s accessibility, readability and usability.

---

### Accessibility requirements

**User need:**  
> I can read and understand text, even if there are unusual words and shortened forms, or languages other than English.

**Fundamentals:**  

- Use a consistent type style. For some users, it can be difficult to read the text when presented in a style that is different or unfamiliar. This includes changes to the shapes of letters, as between roman and italic type.  
- Avoid chunks of italic text.

**Web Content Accessibility Guidelines success criterion:**  

Guideline 3.1 – readable. (WCAG 2.0 advisory techniques remain relevant.)

---

## Italicise titles of stand-alone works, legal cases and Acts

A title or name in italic type shows that it is formal and complete. Shortened versions of the title and common titles are in roman type. Follow the detailed guidance for referencing and attribution.

Don’t use italics for the titles of sacred texts, such as the Bible or the Koran.

**Published works**  
Use italics for the titles of these published works:

- books and periodicals  
- plays  
- classics  
- most musical compositions  
- ballets and operas  
- films, videos and podcasts  
- blogs  
- television and radio programs  
- artworks.  

**Example**  
> David Williamson’s play *Emerald City* was first performed in 1987.  
> Elena Kats-Chernin’s *Piano concerto no. 3* is a recent work by the award-winning composer.  
> In 2018, Yvette Coppersmith won the Archibald Prize with *Self-portrait, after George Lambert*.

Unpublished works are in roman type.

---

### Reverse italics in titles of published works

In some titles, there are words that would normally be italicised. To make sure they stand out from the rest of the italicised title, write the words in roman type. This is called ‘reverse italics’.

**Example**  
> *Gone on The Ghan and other great railway journeys of Australia*  
> [*The Ghan* is the official name of a train; it would normally be italicised.]

---

### Full titles of Acts and legal cases

Use italics for primary legislation and legal cases but not for delegated legislation or bills. Follow the guidance for legal material.

**Example**  
> The Franklin Dam Case is the informal title of *Commonwealth v Tasmania* (1983) 158 CLR 1. The case led to the World Heritage Properties Conservation Bill which became an Act in 1983. In 1999, the Act was replaced by parts of the *Environment Protection and Biodiversity Conservation Act 1999*.  

[The case name and the Act are italicised; the name for the bill, before enacted, is in roman type.]

---

## Set off most foreign words and phrases

Italics contrast words and phrases that are not in English from surrounding text. Foreign words and phrases should generally be avoided in government writing, unless there is no English equivalent.

**Example**  
> The more things change, *plus c’est la même*.

Standard Australian English can absorb words or phrases from other languages. Write these ‘borrowed’ words without italics or accent marks.

**Example**  
> John was the head barista at the department’s coffee shop.

Check a dictionary if you are unsure about whether a word of foreign origin should be italics.

Do not italicise names or words from First Nations languages. They are Australian languages, not foreign languages.

---

## Don’t use italics for Latin shortened forms

The ‘common use’ principle applies to Latin shortened forms (such as ‘etc.’ and ‘i.e.’). Write the full Latin word in italics but not the shortened form.

**Example**  
> The abbreviation ‘cf.’ is from the Latin word *confer* and means ‘compare’.

---

## Show that formulas and some text have special meaning

Italics are often used for the first instance of a technical term when it’s defined or introduced for the first time. Instead, to draw attention to words with special meaning, use single quotation marks.

Specialist uses of italics include well-known mathematical theorems and formulas.

**Example**  
> Pythagoras’s theorem for a right-angled triangle proved that *a² + b² = c²*.

---

### Special material

Some content needs to be set apart from the text for readers to make sense of it. Examples of italicised notes, instructions and extra material in published works include:

- Theatre and film scripts can use italics for stage directions.  
- Books often italicise a prelude or brief introductory remark to set the scene.  
- Musical scripts sometimes use italics for instructions.  

Remember to avoid blocks of italics wherever possible. Blocks of italics are difficult to read, so consider other formatting and design options.

---

### Official names of vehicles

Ships, trains, aircraft and other vehicles sometimes have a proper name. The name is in italics excluding any definite article. The brand or type of vehicle is in roman type.

**Example**  
> Until 1997, Queen Elizabeth II would use the *Britannia* to sail to official visits overseas. [The definite article ‘the’ is in roman type, while the ship’s official name is in italics.]  
> Qantas uses Australian names like *Great Southern Land* for the Dreamliner fleet.

---

### Scientific names

Use italics for the genus and species, including any subspecies, but not for the common name.

Write the scientific names of infectious organisms, including some bacteria and fungi, in italics.

**Example**  
> *Acacia phlebocarpa* is the scientific name for the tabletop wattle.  
> Certain strains of the bacteria *Staphylococcus aureus* cause golden staph.

---

## Stress words with special emphasis, but rarely

Sometimes you want to stress a word for meaning or to convey emotion, including a change in tone. Italics, used sparingly, can work for this purpose.

**Example**  
> ‘I didn’t mean *her*,’ they said, ‘I meant *him*.’  
> The deadline is Monday, not Friday.

Don’t use italics when another style or formatting option is available. Single quotation marks can work for emphasis unless they’re serving a different stylistic use.

---

### Emphasis in quotations

Sometimes, you might want to add italics to quotations to bring attention to particular words or phrases. If you do this, write ‘emphasis added’ in square brackets following the italicised text. This way, people will know the italics didn’t appear in the original quotation.

**Example**  
> ‘Subsequently, in 1903, Parliament passed a unanimous resolution that it should be flown.’ [emphasis added]

If the italics is part of the original text, write ‘emphasis from original’ in the square brackets following the quotation.

---

## Release notes

The digital edition revises guidance on italics.

- The *Content Guide* recommended avoiding use of italics. The digital edition outlines limited uses for italics. It reinstates the use of italics for Acts and titles of formal publications.  
- The sixth edition use of italics for titles is retained, with the exception of long poems. Italicised titles are now reserved for poems in book form.  
- The digital edition departs from sixth edition advice to use italics for letters, words and phrases cited as themselves, terms that are deliberately misused and terms that are newly coined. This reflects expert advice about limiting the use of italics in digital content to ensure readability and accessibility.  
- The guidance for reverse italics has changed from the sixth edition, which recommended single quotes in addition to roman type for words embedded in an italicised title. The digital edition change is in keeping with the principle of minimal punctuation.  
- The digital edition recommends against use of italics for names or words from Aboriginal and Torres Strait Islander languages. This departs from stylistic convention: ‘borrowed’ words (not absorbed into Australian English) are otherwise italicised.
